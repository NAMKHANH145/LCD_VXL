#include "i2c_lcd.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <stdio.h>
#include <unistd.h>

static const char *TAG = "LCD";

// Biến lưu địa chỉ I2C thực tế sau khi quét
static uint8_t slcd_addr = LCD_ADDR;

// Biến cục bộ lưu trạng thái đèn nền
static uint8_t lcd_backlight_state = LCD_BACKLIGHT;

static esp_err_t i2c_master_init(void)
{
    i2c_config_t conf = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = I2C_SDA_PIN,
        .scl_io_num = I2C_SCL_PIN,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        // GIẢM TỐC ĐỘ XUỐNG 10kHz ĐỂ TĂNG ĐỘ ỔN ĐỊNH
        .master.clk_speed = 10000, 
    };
    i2c_param_config(I2C_NUM, &conf);
    return i2c_driver_install(I2C_NUM, conf.mode, 0, 0, 0);
}

// Hàm Ping địa chỉ I2C (Check ACK)
static esp_err_t i2c_master_probe(i2c_port_t i2c_num, uint8_t address)
{
    i2c_cmd_handle_t cmd = i2c_cmd_link_create();
    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (address << 1) | I2C_MASTER_WRITE, true);
    i2c_master_stop(cmd);
    // Tăng timeout lên 100ms
    esp_err_t ret = i2c_master_cmd_begin(i2c_num, cmd, 100 / portTICK_PERIOD_MS);
    i2c_cmd_link_delete(cmd);
    return ret;
}

static void lcd_write_nibble(uint8_t nibble, uint8_t mode)
{
    uint8_t data = (nibble & 0xF0) | mode | lcd_backlight_state;
    uint8_t tx_data[2];
    tx_data[0] = data | EN;
    tx_data[1] = data;
    
    esp_err_t err = i2c_master_write_to_device(I2C_NUM, slcd_addr, tx_data, 2, 100 / portTICK_PERIOD_MS);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "I2C Write Failed (Addr: 0x%02X)", slcd_addr);
    }
}

static void lcd_send_byte(uint8_t data, uint8_t mode)
{
    uint8_t data_u = (data & 0xF0);
    uint8_t data_l = ((data << 4) & 0xF0);
    lcd_write_nibble(data_u, mode);
    lcd_write_nibble(data_l, mode);
}

void lcd_send_cmd(uint8_t cmd) { lcd_send_byte(cmd, 0); }
void lcd_send_data(uint8_t data) { lcd_send_byte(data, RS); }

void lcd_clear(void)
{
    lcd_send_cmd(LCD_CLEAR);
    vTaskDelay(20 / portTICK_PERIOD_MS); // Tăng delay cho an toàn
}

void lcd_put_cur(int row, int col)
{
    switch (row) {
        case 0: col |= 0x80; break;
        case 1: col |= 0xC0; break;
    }
    lcd_send_cmd(col);
}

void lcd_backlight_on(void) {
    lcd_backlight_state = LCD_BACKLIGHT;
    uint8_t data = lcd_backlight_state; 
    i2c_master_write_to_device(I2C_NUM, slcd_addr, &data, 1, 100 / portTICK_PERIOD_MS);
}

void lcd_backlight_off(void) {
    lcd_backlight_state = LCD_NOBACKLIGHT;
    uint8_t data = lcd_backlight_state;
    i2c_master_write_to_device(I2C_NUM, slcd_addr, &data, 1, 100 / portTICK_PERIOD_MS);
}

esp_err_t lcd_init(void)
{
    esp_err_t err = i2c_master_init();
    if (err != ESP_OK) return err;
    
    ESP_LOGI(TAG, "I2C initialized at 10kHz. Scanning ALL addresses (0x00 - 0x7F)...");
    
    bool found = false;
    // Quét TOÀN BỘ dải địa chỉ I2C
    for (uint8_t addr = 0; addr < 127; addr++) {
        // Bỏ qua các địa chỉ reserved
        if (addr < 3 || addr > 119) continue;

        if (i2c_master_probe(I2C_NUM, addr) == ESP_OK) {
            ESP_LOGI(TAG, "--> Found I2C Device at: 0x%02X", addr);
            if (!found) {
                slcd_addr = addr; // Lấy thiết bị đầu tiên tìm thấy làm LCD
                found = true;
            }
        }
    }

    if (!found) {
        ESP_LOGE(TAG, "NO DEVICES FOUND! Check Pull-up resistors and Connections (SDA=21, SCL=22).");
        return ESP_ERR_NOT_FOUND;
    }
    
    ESP_LOGI(TAG, "Using LCD at Address: 0x%02X", slcd_addr);

    // Initialization Sequence
    vTaskDelay(100 / portTICK_PERIOD_MS); // Wait longer
    lcd_write_nibble(0x30, 0); vTaskDelay(10 / portTICK_PERIOD_MS); 
    lcd_write_nibble(0x30, 0); vTaskDelay(5 / portTICK_PERIOD_MS); 
    lcd_write_nibble(0x30, 0); vTaskDelay(5 / portTICK_PERIOD_MS);
    lcd_write_nibble(0x20, 0); vTaskDelay(5 / portTICK_PERIOD_MS);

    lcd_send_cmd(LCD_FUNCTION_SET | LCD_4BITMODE | LCD_2LINE | LCD_5x8DOTS); 
    vTaskDelay(2 / portTICK_PERIOD_MS);
    lcd_send_cmd(LCD_DISPLAY_CONTROL | LCD_DISPLAYOFF);
    vTaskDelay(2 / portTICK_PERIOD_MS);
    lcd_clear(); 
    lcd_send_cmd(LCD_ENTRY_MODE | LCD_ENTRY_INC | LCD_ENTRY_NOSHIFT); 
    vTaskDelay(2 / portTICK_PERIOD_MS);
    lcd_send_cmd(LCD_DISPLAY_CONTROL | LCD_DISPLAYON | LCD_CURSOROFF | LCD_BLINKOFF); 
    
    return ESP_OK;
}

void lcd_send_string(char *str) { while (*str) lcd_send_data((uint8_t)(*str++)); }
void lcd_send_int(int number) { char buffer[16]; sprintf(buffer, "%d", number); lcd_send_string(buffer); }
void lcd_send_float(float number, int precision) {
    char buffer[16], format[10];
    sprintf(format, "%%.%df", precision);
    sprintf(buffer, format, number);
    lcd_send_string(buffer);
}
